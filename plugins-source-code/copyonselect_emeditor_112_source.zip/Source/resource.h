//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//

#define IDC_TEXT                        1010
#define IDC_SHOW_DIALOG                 1011

#define IDS_MENU_TEXT                   1
#define IDS_STATUS_MESSAGE              2
#define IDS_SURE_TO_UNINSTALL           3
#define IDS_VERSION                     4

#define IDB_16164_DEFAULT               101
#define IDB_16168_DEFAULT               102
#define IDB_24244_DEFAULT               103
#define IDB_24248_DEFAULT               104

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
