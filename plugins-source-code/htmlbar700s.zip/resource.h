//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by HTMLBar.rc
//
#define IDS_SURE_TO_UNINSTALL           1
#define IDS_VERSION                     2
#define IDS_MENU_TEXT                   3
#define IDS_STATUS_MESSAGE              4
#define IDS_WORDS_CONTAINED             5
#define IDS_TITLE                       5
#define IDS_INVALID_VERSION             7
#define IDS_FILE                        8
#define IDS_FILTER_IMAGE                8
#define IDS_LINE                        9
#define IDS_PICTURE                     9
#define IDS_FILTER_HYPERLINK            10
#define IDS_POS_LEFT                    11
#define IDS_HYPERLINK                   11
#define IDS_POS_TOP                     12
#define IDS_CONFIGS                     12
#define IDS_POS_RIGHT                   13
#define IDS_POS_BOTTOM                  14
#define IDD_FONT                        100
#define IDB_BITMAP                      101
#define IDB_256C_16_BW                  103
#define IDD_FIND_BAR                    103
#define IDD_DIALOGBAR                   103
#define IDB_256C_16_DEFAULT             104
#define IDB_256C_16_HOT                 105
#define IDB_256C_24_BW                  106
#define IDB_256C_24_DEFAULT             107
#define IDB_256C_24_HOT                 108
#define IDB_TRUE_16_BW                  109
#define IDB_TRUE_16_DEFAULT             110
#define IDB_TRUE_16_HOT                 111
#define IDB_TRUE_24_BW                  112
#define IDB_TRUE_24_DEFAULT             113
#define IDB_TRUE_24_HOT                 114
#define IDB_16C_24                      115
#define IDD_PROP                        116
#define IDR_CONTEXT_MENU                117
#define IDD_SEARCH                      118
#define IDB_TOOLBAR                     134
#define IDR_POPUP_HEADER                135
#define IDR_POPUP_FONT                  136
#define IDD_TABLE                       137
#define IDR_POPUP_FORM                  138
#define IDB_BITMAP1                     145
#define IDR_REGEXP_FIND_POPUP           195
#define IDC_REGEX1                      1000
#define IDC_MATCH1                      1001
#define IDC_REGEX2                      1002
#define IDC_MATCH2                      1003
#define IDC_RESET                       1004
#define IDC_FIND                        1005
#define IDC_REGEX3                      1006
#define IDC_SEARCH                      1006
#define IDC_MATCH3                      1007
#define IDC_REGEX4                      1008
#define IDC_LIST                        1008
#define IDC_MATCH4                      1009
#define IDC_CASE                        1009
#define IDC_REGEX5                      1010
#define IDC_REGEX                       1010
#define IDC_MATCH5                      1011
#define IDC_REGEX6                      1012
#define IDC_BROWSE_REG_EXP              1012
#define IDC_MATCH6                      1013
#define IDC_INCREMENTAL                 1013
#define IDC_OPEN_DOC                    1014
#define IDC_REG_EXP                     1016
#define IDC_ESCAPE                      1017
#define IDC_ONLY_WORD                   1018
#define IDC_AROUND                      1019
#define IDC_ROWS                        1020
#define IDC_COLUMNS                     1021
#define IDC_AUTO_DISPLAY                1022
#define IDC_COMBO_POS                   1024
#define ID_HEADER                       40000
#define ID_PARAGRAPH                    40001
#define ID_BREAK                        40002
#define ID_BOLD                         40003
#define ID_ITALIC                       40004
#define ID_UNDERLINE                    40005
#define ID_FONT                         40006
#define ID_COLOR                        40007
#define ID_PICTURE                      40008
#define ID_HYPERLINK                    40009
#define ID_TABLE                        40010
#define ID_HORZ_LINE                    40011
#define ID_COMMENT                      40012
#define ID_ALIGN_LEFT                   40013
#define ID_CENTER                       40014
#define ID_ALIGN_RIGHT                  40015
#define ID_JUSTIFY                      40016
#define ID_NUMBERING                    40017
#define ID_BULLETS                      40018
#define ID_UNINDENT                     40019
#define ID_INDENT                       40020
#define ID_HIGHLIGHT                    40021
#define ID_FONT_COLOR                   40022
#define ID_FORM                         40023
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        146
#define _APS_NEXT_COMMAND_VALUE         40006
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
