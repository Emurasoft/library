//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by docComp.rc
//
#define IDD_MAIN                        9
#define IDS_MENUTEXT                    101
#define IDS_STATUSMESSAGE               102
#define IDB_BUTTON                      102
#define IDS_NAME                        103
#define IDS_VERSION                     104
#define IDD_DIALOG1                     104
#define IDD_OPTION                      104
#define IDS_SYSNAME                     105
#define IDD_DIALOG2                     105
#define IDD_SELECT                      105
#define IDS_NONAME                      106
#define IDD_SPACES                      106
#define IDS_DISCREPANCY                 107
#define IDS_COMPLATE                    108
#define IDL_FILES                       1002
#define IDC_ALWAYS_SELECTOR             1003
#define IDC_IGNORE_SPACE                1004
#define IDC_IGNORE_NULLLINE             1005
#define IDC_CASE_SENSITIVE              1006
#define IDC_DOCLIST                     1011
#define IDC_SPACE                       1012
#define IDC_IDEOGRAPHIC_SPACE           1013
#define IDC_CHARACTER_TABULATION        1014
#define IDC_ADVANCE_OPTION              1015
#define IDC_NO_BREAK_SPACE              1016
#define IDC_OGHAM_SPACE_MARK            1017
#define IDC_MONGOLIAN_VOWEL_SEPARATOR   1018
#define IDC_EN_QUAD                     1019
#define IDC_EM_QUAD                     1020
#define IDC_EN_SPACE                    1021
#define IDC_EM_SPACE                    1022
#define IDC_THREE_PER_EM_SPACE          1023
#define IDC_FOUR_PER_EM_SPACE           1024
#define IDC_SIX_PER_EM_SPACE            1025
#define IDC_FIGURE_SPACE                1026
#define IDC_PUNCTUATION_SPACE           1027
#define IDC_THIN_SPACE                  1028
#define IDC_HAIR_SPACE                  1029
#define IDC_NARROW_NO_BREAK_SPACE       1030
#define IDC_MEDIUM_MATHEMATICAL_SPACE   1031
#define IDC_LINE_SEPARATOR              1032
#define IDC_PARAGRAPH_SEPARATOR         1033
#define IDC_LINE_FEED                   1034
#define IDC_LINE_TABULATION             1035
#define IDC_FORM_FEED                   1036
#define IDC_CARRIAGE_RETURN             1037
#define IDC_NEXT_LINE                   1038
#define IDC_GROUP_OTHER                 1039
#define IDC_GROUP_ZS                    1040
#define IDC_GROUP_ZL                    1041
#define IDC_GROUP_ZP                    1042
#define IDC_GROUP_CC                    1043
#define IDC_GROUP_JP                    1044
#define IDC_SPACES                      1045

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1046
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
