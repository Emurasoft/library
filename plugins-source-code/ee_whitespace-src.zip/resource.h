//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by resource.rc
//
#define IDS_MENU_TEXT                   101
#define IDS_STATUS_MESSAGE              102
#define IDS_VERSION                     103
#define IDS_SURE_TO_UNINSTALL           104

#define IDB_24_24_32                    201
#define IDB_24_24_32_DISABLED           202
#define IDB_24_24_32_HOVER              203
#define IDB_24_24_8                     204
#define IDB_24_24_8_DISABLED            205
#define IDB_24_24_8_HOVER               206
#define IDB_24_24_4                     207
#define IDB_16_16_32                    208
#define IDB_16_16_32_DISABLED           209
#define IDB_16_16_32_HOVER              210
#define IDB_16_16_8                     211
#define IDB_16_16_8_DISABLED            212
#define IDB_16_16_8_HOVER               213
#define IDB_16_16_4                     214

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
