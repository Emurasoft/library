//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DecodeUnicode.rc
//
#define IDS_SURE_TO_UNINSTALL           1
#define IDS_VERSION                     2
#define IDS_MENU_TEXT                   3
#define IDS_STATUS_MESSAGE              4
#define IDD_PROP                        101
#define IDB_BITMAP                      101
#define IDB_256C_16_DEFAULT             104
#define IDB_256C_16_BW                  105
#define IDB_256C_16_HOT                 107
#define IDB_16C_24                      109
#define IDB_256C_24_BW                  110
#define IDB_256C_24_DEFAULT             111
#define IDB_256C_24_HOT                 112
#define IDB_TRUE_16_BW                  113
#define IDB_TRUE_16_DEFAULT             114
#define IDB_TRUE_16_HOT                 115
#define IDB_TRUE_24_BW                  117
#define IDB_TRUE_24_DEFAULT             118
#define IDB_TRUE_24_HOT                 119
#define IDC_HTML                        1002
#define IDC_UCN                         1003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
