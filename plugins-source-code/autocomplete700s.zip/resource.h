//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by AutoComplete.rc
//
#define IDS_SURE_TO_UNINSTALL           1
#define IDS_VERSION                     2
#define IDS_MENU_TEXT                   3
#define IDS_STATUS_MESSAGE              4
#define IDS_FILTER_EAC                  5
#define IDS_INVALID_VERSION             6
#define IDB_BITMAP                      101
#define IDD_AUTO_COMPLETE               103
#define IDB_256C_16_DEFAULT             104
#define IDB_256C_16_BW                  105
#define IDB_256C_16_HOT                 107
#define IDB_16C_24                      109
#define IDB_256C_24_BW                  110
#define IDB_256C_24_DEFAULT             111
#define IDB_256C_24_HOT                 112
#define IDB_TRUE_16_BW                  113
#define IDB_TRUE_16_DEFAULT             114
#define IDB_TRUE_16_HOT                 115
#define IDB_TRUE_24_BW                  117
#define IDB_TRUE_24_DEFAULT             118
#define IDB_TRUE_24_HOT                 119
#define IDC_IMPORT                      1001
#define IDC_EXPORT                      1002
#define IDC_ALTERNATE_CHAR              1004
#define IDC_AUTO_INDENT                 1005
#define IDC_TIP                         1007
#define IDC_USE_CONFIG                  1009
#define IDC_COMBO_CONFIG                1010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        120
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
