#pragma once

#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <windowsx.h>
#include <commdlg.h>
#include <tchar.h>
#include <malloc.h>
#include <commctrl.h>
#include <strsafe.h>
#include <crtdbg.h>

#ifdef _DEBUG
#define VERIFY(f)          _ASSERTE(f)
#else
#define VERIFY(f)          ((void)(f))
#endif

#pragma warning( push )
#pragma warning( disable : 4995 ) // 'function': name was marked as #pragma deprecated
#pragma warning( disable : 4244 )  // 'argument' : conversion from '__w64 unsigned int' to 'rsize_t', possible loss of data
#include <vector>
#include <string>
#include <map>
#pragma warning( pop )

#ifdef _DEBUG
   #define _DEBUG_NEW   new( _NORMAL_BLOCK, __FILE__, __LINE__)
#else
   #define _DEBUG_NEW
#endif // _DEBUG

using namespace std;

