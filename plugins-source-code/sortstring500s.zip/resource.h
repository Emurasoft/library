//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SortStringA.rc
//
#define IDS_SURE_TO_UNINSTALL           1
#define IDS_VERSION                     2
#define IDS_MENU_TEXT_A                 3
#define IDS_STATUS_MESSAGE_A            4
#define IDS_MENU_TEXT_D                 5
#define IDS_STATUS_MESSAGE_D            6
#define IDB_BITMAP                      101
#define IDD_SORT_STRING                 103
#define IDB_LARGE_BITMAP                104
#define IDB_16_256C_DISABLED            105
#define IDB_16_256C_DEFAULT             106
#define IDB_16_256C_HOT                 107
#define IDB_16_TRUE_DISABLED            108
#define IDB_16_TRUE_DEFAULT             109
#define IDB_16_TRUE_HOT                 111
#define IDB_24_256C_DISABLED            112
#define IDB_24_256C_DEFAULT             113
#define IDB_24_256C_HOT                 114
#define IDB_24_TRUE_DISABLED            115
#define IDB_24_TRUE_DEFAULT             116
#define IDB_24_TRUE_HOT                 117
#define IDC_COMBO_LOCALE                1000
#define IDC_IGNORE_CASE                 1001
#define IDC_IGNORE_KANA_TYPE            1002
#define IDC_IGNORE_NONSPACE             1003
#define IDC_IGNORE_SYMBOLS              1004
#define IDC_IGNORE_WIDTH                1005
#define IDC_STRING_SORT                 1006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
