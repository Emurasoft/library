//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by docNavi.rc
//
#define IDD_MAIN                        9
#define IDS_MENUTEXT                    101
#define IDS_STATUSMESSAGE               102
#define IDB_BUTTON                      102
#define IDS_NAME                        103
#define IDS_VERSION                     104
#define IDD_OPTION                      104
#define IDS_NONAME                      105
#define IDS_SYSNAME                     106
#define IDL_FILES                       1002
#define IDC_HIT_TOP                     1005
#define IDC_CHECK2                      1006
#define IDC_HIT_INCLUDE                 1006
#define IDC_RELATIVE                    1007
#define IDC_RELATIVE_FRAME              1008
#define IDC_TRACEBACK                   1009
#define IDC_SPIN1                       1010
#define IDC_TRACEBACK_SPIN              1010
#define IDC_TRACEBACK_LABEL             1011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
