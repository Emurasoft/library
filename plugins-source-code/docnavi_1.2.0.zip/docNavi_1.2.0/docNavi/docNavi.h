﻿#pragma once
#include <windows.h>

namespace docNavi {

	//	プロパティ開く
	//		hwnd	EmEditorウィンドウハンドル
	extern	bool	ShowProperty( HWND hwnd );

	//	ドキュメントリスト開く
	//		hwnd	EmEditorウィンドウハンドル
	extern	void	ShowDocumentList( HWND hwnd );

};

