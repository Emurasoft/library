﻿#pragma once

#if defined(_USING_V110_SDK71_)
  #define _WIN32_WINNT	_WIN32_WINNT_WINXP	//	WindowsXP以降用
#else
  #define _WIN32_WINNT	_WIN32_WINNT_VISTA	//	WindowsVista以降用
#endif

#define STRICT

#include <WinSDKVer.h>
#include <SDKDDKVer.h>

#include <windows.h>
#include <Commctrl.h>
#include <Uxtheme.h>
#include <Vssym32.h>
#include <memory>
#include <vector>
#include <algorithm>
#include <functional>
#include <cassert>
#include <cwchar>
#include "plugin.h"
