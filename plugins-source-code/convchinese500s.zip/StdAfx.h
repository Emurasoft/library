#pragma once

#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <windowsx.h>
#include <tchar.h>
#include <stdlib.h>
#include <commctrl.h>
#include <crtdbg.h>

#ifdef _DEBUG
#define VERIFY(f)          ASSERT(f)
#else   // _DEBUG
#define VERIFY(f)          ((void)(f))
#endif // !_DEBUG

