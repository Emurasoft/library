//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SortNumber.rc
//
#define IDS_SURE_TO_UNINSTALL           1
#define IDS_VERSION                     2
#define IDS_MENU_TEXT_A                 3
#define IDS_STATUS_MESSAGE_A            4
#define IDS_MENU_TEXT_D                 5
#define IDS_STATUS_MESSAGE_D            6
#define IDB_BITMAP                      101
#define IDD_SORT_NUMBER                 101
#define IDB_16C_24                      103
#define IDB_LARGE_BITMAP                104
#define IDB_256C_16_BW                  104
#define IDB_256C_16_DEFAULT             105
#define IDB_256C_16_HOT                 106
#define IDB_256C_24_BW                  107
#define IDB_256C_24_DEFAULT             108
#define IDB_256C_24_HOT                 109
#define IDB_TRUE_16_BW                  110
#define IDB_TRUE_16_DEFAULT             111
#define IDB_TRUE_16_HOT                 112
#define IDB_TRUE_24_BW                  113
#define IDB_TRUE_24_DEFAULT             114
#define IDB_TRUE_24_HOT                 115
#define IDC_INTEGER                     1001
#define IDC_DECIMAL                     1002
#define IDC_IGNORE_PREFIX               1003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
