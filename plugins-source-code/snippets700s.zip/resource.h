//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Snippets.rc
//
#define IDS_SURE_TO_UNINSTALL           1
#define IDS_VERSION                     2
#define IDS_MENU_TEXT                   3
#define IDS_STATUS_MESSAGE              4
#define IDS_WORDS_CONTAINED             5
#define IDS_SURE_DELETE                 5
#define IDS_SURE_DELETE_FOLDER          6
#define IDS_INVALID_VERSION             7
#define IDS_POS_LEFT                    11
#define IDS_POS_TOP                     12
#define IDS_POS_RIGHT                   13
#define IDS_POS_BOTTOM                  14
#define IDB_BITMAP                      101
#define IDB_IMAGE                       102
#define IDB_256C_16_BW                  103
#define IDB_256C_16_DEFAULT             104
#define IDB_256C_16_HOT                 105
#define IDB_256C_24_BW                  106
#define IDB_256C_24_DEFAULT             107
#define IDB_256C_24_HOT                 108
#define IDB_TRUE_16_BW                  109
#define IDB_TRUE_16_DEFAULT             110
#define IDB_TRUE_16_HOT                 111
#define IDB_TRUE_24_BW                  112
#define IDB_TRUE_24_DEFAULT             113
#define IDB_TRUE_24_HOT                 114
#define IDB_16C_24                      115
#define IDD_PROP                        116
#define IDR_CONTEXT_MENU                118
#define IDC_REGEX1                      1000
#define IDC_MATCH1                      1001
#define IDC_REGEX2                      1002
#define IDC_MATCH2                      1003
#define IDC_RESET                       1004
#define IDC_REGEX3                      1006
#define IDC_MATCH3                      1007
#define IDC_REGEX4                      1008
#define IDC_MATCH4                      1009
#define IDC_REGEX5                      1010
#define IDC_MATCH5                      1011
#define IDC_REGEX6                      1012
#define IDC_MATCH6                      1013
#define IDC_COMBO_POS                   1024
#define ID_NEW_TEXT                     40001
#define ID_NEW_FOLDER                   40002
#define ID_DELETE                       40003
#define ID_RENAME                       40004
#define ID_MOVE_UP                      40005
#define ID_MOVE_DOWN                    40006
#define ID_INSERT                       40007
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         40008
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
