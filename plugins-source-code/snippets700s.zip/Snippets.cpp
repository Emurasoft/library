// WordCount.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include "resource.h"

// the following line is needed before #include <etlframe.h>
#define ETL_FRAME_CLASS_NAME CMyFrame
#include <etlframe.h>
#include "mystring.h"
#include "myreg.h"
#include "Snippets.h"

