// stdafx.h
//

#if !defined(AFX_STDAFX_H__8C6DC385_965D_11D3_B1F6_0020AFD3858C__INCLUDED_)
#define AFX_STDAFX_H__8C6DC385_965D_11D3_B1F6_0020AFD3858C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>

//{{AFX_INSERT_LOCATION}}
// 

#endif // !defined(AFX_STDAFX_H__8C6DC385_965D_11D3_B1F6_0020AFD3858C__INCLUDED_)
