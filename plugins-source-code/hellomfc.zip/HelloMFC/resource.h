//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by HelloMFC.rc
//
#define IDS_MENU_TEXT                   101
#define IDS_STATUS_MESSAGE              102
#define IDS_VERSION                     103
#define IDS_SURE_TO_UNINSTALL           104
#define IDC_CHECK1                      2000
#define IDC_EDIT1                       2001
#define IDB_BITMAP                      2004
#define IDD_DIALOG1                     2005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        2006
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         2002
#define _APS_NEXT_SYMED_VALUE           2000
#endif
#endif
