// stdafx.h
//

#if !defined(AFX_STDAFX_H__2F399381_5E98_11D3_8C11_00C04FB62B1B__INCLUDED_)
#define AFX_STDAFX_H__2F399381_5E98_11D3_8C11_00C04FB62B1B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <windowsx.h>
#include <tchar.h>

#include "plugin.h"
#include "devil_compile.h"
#include "devil_config.h"



//{{AFX_INSERT_LOCATION}}
// 

#endif // !defined(AFX_STDAFX_H__2F399381_5E98_11D3_8C11_00C04FB62B1B__INCLUDED_)
