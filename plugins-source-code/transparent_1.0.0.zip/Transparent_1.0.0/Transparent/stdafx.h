#pragma once

#include <WinSDKVer.h>

#define	_WIN32_WINNT		_WIN32_WINNT_WINXP

#include <SDKDDKVer.h>
#include <windows.h>
#include <Commctrl.h>
#include <string>
#include <set>
#include <strsafe.h>
#include <assert.h>

#include "plugin.h"
