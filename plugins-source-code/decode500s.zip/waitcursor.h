class CWaitCursor
{
public:
	HCURSOR m_hPrevCursor;
	CWaitCursor() {
		m_hPrevCursor = SetCursor(LoadCursor(NULL, IDC_WAIT));
	};
	~CWaitCursor() {
		SetCursor( m_hPrevCursor );
	};
};

