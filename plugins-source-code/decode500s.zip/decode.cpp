// decode.cpp
//

#include "stdafx.h"
#include "resource.h"

// the following line is needed before #include "etlframe.h"
#define ETL_FRAME_CLASS_NAME CMyFrame
#include <etlframe.h>
#include "mystring.h"
#include "waitcursor.h"
#include "decode.h"

