//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ �Ő������ꂽ�C���N���[�h �t�@�C���B
// ScrollMargin.rc �Ŏg�p
//
#define IDS_MENUTEXT                    101
#define IDS_STATUSMESSAGE               102
#define IDB_BUTTON                      102
#define IDS_NAME                        103
#define IDS_VERSION                     104
#define IDD_DIALOG1                     104
#define IDS_SYSNAME                     105
#define IDD_PROPERTY                    105
#define IDS_ERROR_DELAY                 106
#define IDS_COMMENT                     107
#define IDC_MOUSE_CANCEL                1017
#define IDC_MARGIN_UP                   1018
#define IDC_MARGIN_DOWN                 1019
#define IDC_CHECK1                      1020
#define IDC_IDLE_TO_REDRAW              1020
#define IDC_DELAY                       1021
#define IDC_DELAY_SPIN                  1022
#define IDC_DEFAULT_DELAY               1023
#define IDC_RESET_DELAY                 1023
#define IDC_COMMENT                     1024

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1025
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
