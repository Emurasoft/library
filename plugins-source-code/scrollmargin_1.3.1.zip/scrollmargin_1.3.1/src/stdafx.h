#pragma once

#if defined(_USING_V110_SDK71_)
  #define _WIN32_WINNT	_WIN32_WINNT_WINXP	//	WindowsXP�ȍ~�p
#else
  #define _WIN32_WINNT	_WIN32_WINNT_VISTA	//	WindowsVista�ȍ~�p
#endif

#define STRICT

#include <WinSDKVer.h>
#include <SDKDDKVer.h>

#include <windows.h>
#include <crtdbg.h>
#include "plugin.h"

