#pragma once

#define _WIN32_WINNT	_WIN32_WINNT_WINXP	//	WindowsXP�ȍ~�p
#include <WinSDKVer.h>
#include <SDKDDKVer.h>

