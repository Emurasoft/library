﻿#pragma once

#include "config.h"
#include <windows.h>

namespace CaretImeColor {

	//	コマンド実行可能か？
	extern	bool	CanCommand( ::HWND hwnd );
	//	チェックが付いた状態か？
	extern	bool	IsChecked( ::HWND hwnd );

	//	プロパティ開く
	//		hwnd	EmEditorウィンドウハンドル
	extern	bool	ShowProperty( ::HWND hwnd );

	//	コマンド実行
	extern	void	OnCommand( ::HWND hwnd );

	//	イベント応答
	extern	void	OnEvents( ::HWND hwnd, ::UINT nEvent, ::LPARAM lParam );
	extern	void	OnAttachProcess();
	extern	void	OnDetachProcess();
	extern	void	OnAttachThread();
	extern	void	OnDetachThread();
};

