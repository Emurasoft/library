//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by props.rc
//
#define IDS_SURE_TO_UNINSTALL           1
#define IDS_VERSION                     2
#define IDS_MENU_TEXT                   3
#define IDS_STATUS_MESSAGE              4
#define IDB_BITMAP                      101
#define IDR_MENU                        102
#define IDB_16C_24                      103
#define IDB_256C_16_BW                  104
#define IDB_256C_16_DEFAULT             105
#define IDB_256C_16_HOT                 106
#define IDB_256C_24_BW                  107
#define IDB_256C_24_DEFAULT             108
#define IDB_256C_24_HOT                 109
#define IDB_TRUE_16_BW                  110
#define IDB_TRUE_16_DEFAULT             111
#define IDB_TRUE_16_HOT                 112
#define IDB_TRUE_24_BW                  113
#define IDB_TRUE_24_DEFAULT             114
#define IDB_TRUE_24_HOT                 115
#define ID_SHOW_EOF                     40001
#define ID_SHOW_CR                      40002
#define ID_SHOW_TAB                     40003
#define ID_SHOW_LINE_NUM                40004
#define ID_SHOW_RULER                   40005
#define ID_HORZ_LINE                    40007
#define ID_VERT_LINE                    40008
#define ID_SHOW_DBSPACE                 40009
#define ID_SCROLL_2LINES                40010
#define ID_FAST_KEY_REPEAT              40011
#define ID_AUTO_INDENT                  40012
#define ID_SHOW_PAGE                    40013
#define ID_WORD_WRAP                    40014
#define ID_KINSOKU_WRAP                 40015
#define ID_FACE_WRAP                    40016
#define ID_HILITE                       40017
#define ID_URL                          40018
#define ID_MAIL_TO                      40019
#define ID_LINK_DBCLICK                 40020
#define ID_SAVE_TAB_TO_SPACE            40021
#define ID_SAVE_INSERT_CR               40022
#define ID_DELETE_EMPTY                 40023

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        116
#define _APS_NEXT_COMMAND_VALUE         40024
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
