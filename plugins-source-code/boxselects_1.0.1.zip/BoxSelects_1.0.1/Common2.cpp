#include <windows.h>
#include "plugin.h"

//	�ύX�����Ǝv����͈͂��ĕ`��v��
void	InvalidateArea( HWND hwnd, const POINT_PTR& beginViewAnchor, const POINT_PTR& beginViewCaret )
{
	//	�I�[���W�擾
	POINT_PTR	endViewAnchor, endViewCaret;
	Editor_GetAnchorPos( hwnd, POS_VIEW, &endViewAnchor );
	Editor_GetCaretPos(	 hwnd, POS_VIEW, &endViewCaret  );
	
	//	�f�o�C�X���W�ɕϊ�
	POINT_PTR	beginDevAnchor, beginDevCaret, endDevAnchor, endDevCaret;
	Editor_ViewToDev( hwnd, const_cast<POINT_PTR*>(&beginViewAnchor), &beginDevAnchor );
	Editor_ViewToDev( hwnd,						   &endViewAnchor,	  &endDevAnchor	  );
	Editor_ViewToDev( hwnd, const_cast<POINT_PTR*>(&beginViewCaret),  &beginDevCaret  );
	Editor_ViewToDev( hwnd,						   &endViewCaret,	  &endDevCaret	  );

	//	�`��X�V�v��
	static const long gap( 32 );
	RECT	rc = {
		(long)min( min( beginDevAnchor.x, endDevAnchor.x ), min( beginDevCaret.x, endDevCaret.x ) ) - gap,
		(long)min( min( beginDevAnchor.y, endDevAnchor.y ), min( beginDevCaret.y, endDevCaret.y ) ) - gap,
		(long)max( max( beginDevAnchor.x, endDevAnchor.x ), max( beginDevCaret.x, endDevCaret.x ) ) + gap,
		(long)max( max( beginDevAnchor.y, endDevAnchor.y ), max( beginDevCaret.y, endDevCaret.y ) ) + gap
	};
	InvalidateRect( hwnd, &rc, false );
}
