//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by wordcomplete_locj.rc
//
#define IDS_SURE_TO_UNINSTALL           1
#define IDS_VERSION                     2
#define IDS_MENU_TEXT                   3
#define IDS_STATUS_MESSAGE              4
#define IDS_INVALID_VERSION             7
#define IDS_DIC_FILTER                  8
#define IDS_DIC_FILE                    9
#define IDS_CONFIGS                     10
#define IDS_ALL_CONFIG                  11
#define IDS_MATCH_CASE_NEVER            12
#define IDS_MATCH_CASE_CANDIDATES       13
#define IDS_MATCH_CASE_BOTH             14
#define IDS_PRIORITY_LAST_USED          20
#define IDS_PRIORITY_ALPHABETICAL       21
#define IDS_TYPE_NORMAL                 31
#define IDS_TYPE_DOT_SYNTAX             32
#define IDS_TYPE_HTML                   33
#define IDS_TYPE_CUSTOM                 34
#define IDS_COMMAND_SHOW                40
#define IDS_COMMAND_COMPLETE            41
#define IDS_SURE_TO_RESET               50
#define IDS_ACCEL_USED_CORE             51
#define IDD_DICTIONARIES                107
#define IDD_KEYBOARD                    117
#define IDD_OPTIONS                     118
#define IDD_CRITERIA                    119
#define IDD_CONFIG                      137
#define IDC_PROPERTY                    205
#define IDC_SELECT_ALL                  206
#define IDC_LIST_COMMAND                375
#define IDC_EDIT_NEW_KEY                376
#define IDC_LIST_CURRENT_KEY            377
#define IDC_ASSIGN                      378
#define IDC_REMOVE                      379
#define IDC_EXPLANATION                 381
#define IDC_CURRENT_COMMAND             382
#define IDC_STATIC_CURRENT_COMMAND      383
#define IDC_STATIC_2                    663
#define IDC_STATIC_3                    664
#define IDC_STATIC_4                    665
#define IDC_FIRST_MULTI                 683
#define IDC_MID_MULTI                   684
#define IDC_LAST_MULTI                  685
#define IDC_HIDE_WHEN_ONE_CANDIDATE     1001
#define IDC_LIST                        1008
#define IDC_HOW_TO_ESCAPE               1016
#define IDC_LIST_HILITE                 1020
#define IDC_LIST_WORDS_IN_DOC           1021
#define IDC_AUTO_SHOW                   1023
#define IDC_AUTO_COMPLETE               1025
#define IDC_SHOW_ICON                   1026
#define IDC_COLOR_LIST                  1027
#define IDC_NUM_OF_CHARS                1030
#define IDC_SPIN_NUM_OF_CHARS           1031
#define IDC_LINES_BEFORE                1032
#define IDC_LINES_AFTER                 1034
#define IDC_SPIN_LINES_BEFORE           1035
#define IDC_SPIN_LINES_AFTER            1036
#define IDC_LIST_DIC                    1037
#define IDC_DIC_FILE                    1038
#define IDC_BROWSE                      1039
#define IDC_STATIC_FOLDER               1040
#define IDC_HIDE_WHEN_NO_CANDIDATE      1044
#define IDC_LIMIT_LINES                 1045
#define IDC_INCLUDE_PREV_DOC            1046
#define IDC_INCLUDE_DOCS_IN_GROUP       1047
#define IDC_CLIPBOARD                   1049
#define IDC_FILE_NAMES                  1050
#define IDC_FREE_FORMAT                 1051
#define IDC_COMBO_CASE                  1052
#define IDC_COMBO_PRIORITY              1053
#define IDC_COMBO_TYPE                  1054
#define IDC_FIRST_CHAR                  1055
#define IDC_MID_CHAR                    1056
#define IDC_LAST_CHAR                   1057
#define IDS_UNDEFINED                   1058
#define IDC_ONLY_IF_SAME_CONFIG         1059
#define IDS_SURE_ASSIGN_CORE            1059
#define IDC_SHOW_MATCHED_ONLY           1060
#define IDC_SEARCHED_STRINGS            1061
#define IDC_RESET_ALL                   1312
#define IDC_SLIDER_DELAY                1560
#define IDC_STATIC_DELAY                1561
#define IDC_SLIDER_RATE                 1562
#define IDC_STATIC_RATE                 1563

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
