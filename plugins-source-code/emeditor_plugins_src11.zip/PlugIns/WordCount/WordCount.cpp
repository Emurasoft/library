// WordCount.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include "resource.h"
#include "..\mui\wordcount_loce\resource.h"

// the following line is needed before #include <etlframe.h>
#define ETL_FRAME_CLASS_NAME CMyFrame
#include "etlframe.h"
#include "mystring.h"
#include "myreg.h"

#ifdef _DEBUG
#define new _DEBUG_NEW
#else
#define new _RELEASE_NEW
#endif

#include "WordCount.h"

