//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by OutlineText.rc
//
#define IDS_WORDS_CONTAINED             5
#define IDB_BITMAP                      101
#define IDB_256C_16_BW                  103
#define IDB_256C_16_DEFAULT             104
#define IDB_256C_16_HOT                 105
#define IDB_256C_24_BW                  106
#define IDB_256C_24_DEFAULT             107
#define IDB_256C_24_HOT                 108
#define IDB_TRUE_16_BW                  109
#define IDB_TRUE_16_DEFAULT             110
#define IDB_TRUE_16_HOT                 111
#define IDB_TRUE_24_BW                  112
#define IDB_TRUE_24_DEFAULT             113
#define IDB_TRUE_24_HOT                 114
#define IDB_16C_24                      115
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         40010
#define _APS_NEXT_CONTROL_VALUE         1028
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
