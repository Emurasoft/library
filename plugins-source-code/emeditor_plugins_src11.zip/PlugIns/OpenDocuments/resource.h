//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by OpenDocuments.rc
//
#define IDB_BITMAP                      101
#define IDB_TRUE_16_BW                  109
#define IDB_TRUE_16_DEFAULT             110
#define IDB_TRUE_16_HOT                 111
#define IDB_TRUE_24_BW                  112
#define IDB_TRUE_24_DEFAULT             113
#define IDB_TRUE_24_HOT                 114
#define IDB_16C_24                      115

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         40036
#define _APS_NEXT_CONTROL_VALUE         1027
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
