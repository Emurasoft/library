//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ �Ő������ꂽ�C���N���[�h �t�@�C���B
// CaretImeColor.rc �Ŏg�p
//
#define IDS_MENUTEXT                    101
#define IDS_STATUSMESSAGE               102
#define IDB_BUTTON                      102
#define IDS_NAME                        103
#define IDS_VERSION                     104
#define IDD_DIALOG1                     104
#define IDS_SYSNAME                     105
#define IDD_PROPERTY                    105
#define IDS_INQUIRE_RESET               106
#define IDD_DIALOG2                     106
#define IDD_CARET_SIZE                  106
#define IDS_RESET                       107
#define IDS_FONT_SIZE                   108
#define IDS_DEFAULT                     109
#define IDC_COLOR_BTN_CLOSE             1007
#define IDC_COLOR_BTN_OPEN              1008
#define IDC_COLOR_BOX_CLOSE             1009
#define IDC_COLOR_BOX_OPEN              1010
#define IDC_AUTO_CLOSE                  1011
#define IDC_AUTO_OPEN                   1012
#define IDC_BUTTON1                     1013
#define IDC_RESET                       1013
#define IDC_CARET_WIDTH                 1016
#define IDC_CARET_HEIGHT                1017
#define IDC_CARET_SIZE                  1017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
