//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by outlinetext_loce.rc
//
#define IDS_SURE_TO_UNINSTALL           1
#define IDS_VERSION                     2
#define IDS_MENU_TEXT                   3
#define IDS_STATUS_MESSAGE              4
#define IDS_TYPE_CUSTOM_BEGIN_END       5
#define IDS_INVALID_VERSION             7
#define IDS_TYPE_BRACES                 8
#define IDS_TYPE_SPACES                 9
#define IDS_TYPE_CUSTOM                 10
#define IDS_POS_LEFT                    11
#define IDS_POS_TOP                     12
#define IDS_POS_RIGHT                   13
#define IDS_POS_BOTTOM                  14
#define IDS_TYPE_BRACKETS               15
#define IDD_PROP                        116
#define IDR_CONTEXT_MENU                117
#define IDC_REGEX1                      1000
#define IDC_MATCH1                      1001
#define IDC_REGEX2                      1002
#define IDC_MATCH2                      1003
#define IDC_RESET                       1004
#define IDC_COMBO_TYPE                  1005
#define IDC_REGEX3                      1006
#define IDC_MATCH3                      1007
#define IDC_REGEX4                      1008
#define IDC_MATCH4                      1009
#define IDC_REGEX5                      1010
#define IDC_MATCH5                      1011
#define IDC_REGEX6                      1012
#define IDC_MATCH6                      1013
#define IDC_OUTLINE_GUIDE               1015
#define IDC_STATIC_1                    1016
#define IDC_STATIC_2                    1017
#define IDC_STATIC_3                    1018
#define IDC_STATIC_4                    1019
#define IDC_STATIC_5                    1020
#define IDC_STATIC_6                    1021
#define IDC_COMBO_CONFIG                1022
#define IDC_COMBO_POS                   1024
#define IDC_VIEW_LEVEL                  1025
#define IDC_SYNC_CUSTOM_BAR             1027
#define ID_SELECT                       40001
#define ID_GO                           40002
#define ID_MOVE_UP                      40003
#define ID_MOVE_DOWN                    40004
#define ID_PROP                         40005
#define ID_COLLAPSE_ALL                 40006
#define ID_EXPAND_ALL                   40007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
