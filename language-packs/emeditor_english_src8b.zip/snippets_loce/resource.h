//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by snippets_loce.rc
//
#define IDS_SURE_TO_UNINSTALL           1
#define IDS_VERSION                     2
#define IDS_MENU_TEXT                   3
#define IDS_STATUS_MESSAGE              4
#define IDS_SURE_DELETE                 5
#define IDS_SURE_DELETE_FOLDER          6
#define IDS_INVALID_VERSION             7
#define IDS_TOO_LONG_TEXT               8
#define IDS_PARAMETER                   9
#define IDS_VALUE                       10
#define IDS_POS_LEFT                    11
#define IDS_POS_TOP                     12
#define IDS_POS_RIGHT                   13
#define IDS_POS_BOTTOM                  14
#define IDS_NEW_ITEM                    15
#define IDS_NEW_FOLDER                  16
#define IDD_PROP                        116
#define IDR_CONTEXT_MENU                118
#define IDD_INPUT_PARAMS                131
#define IDC_LIST                        1006
#define IDC_COMBO_POS                   1024
#define ID_NEW_TEXT                     40001
#define ID_NEW_FOLDER                   40002
#define ID_DELETE                       40003
#define ID_RENAME                       40004
#define ID_MOVE_UP                      40005
#define ID_MOVE_DOWN                    40006
#define ID_INSERT                       40007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
