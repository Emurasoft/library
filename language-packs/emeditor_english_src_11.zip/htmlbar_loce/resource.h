//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by htmlbar_loce.rc
//
#define IDS_SURE_TO_UNINSTALL           1
#define IDS_VERSION                     2
#define IDS_MENU_TEXT                   3
#define IDS_STATUS_MESSAGE              4
#define IDS_TITLE                       5
#define IDS_INVALID_VERSION             7
#define IDS_FILTER_IMAGE                8
#define IDS_PICTURE                     9
#define IDS_FILTER_HYPERLINK            10
#define IDS_HYPERLINK                   11
#define IDS_CONFIGS                     12
#define IDS_PARAMETER                   13
#define IDS_VALUE                       14
#define IDS_SURE_RESET                  15
#define IDD_FONT                        100
#define IDD_DIALOGBAR                   103
#define IDD_PROP                        116
#define IDD_INPUT_PARAMS                131
#define IDR_POPUP_HEADER                135
#define IDR_POPUP_FONT                  136
#define IDD_TABLE                       137
#define IDR_POPUP_FORM                  138
#define IDD_CUSTOMIZE                   146
#define IDD_CUST_PROP                   147
#define IDR_ARG_POPUP                   178
#define IDC_RESET                       1004
#define IDC_LIST                        1008
#define IDC_ROWS                        1020
#define IDC_COLUMNS                     1021
#define IDC_AUTO_DISPLAY                1022
#define IDC_NEW                         1025
#define IDC_DELETE                      1026
#define IDC_COPY                        1027
#define IDC_UP                          1028
#define IDC_DOWN                        1029
#define IDC_PROP                        1030
#define IDC_TITLE                       1034
#define IDC_TAGS                        1035
#define IDC_TAG_BEGIN                   1036
#define IDC_TAG_END                     1037
#define IDC_SPECIAL                     1039
#define IDC_COMBO_SPECIAL               1042
#define IDC_BROWSE_BEGIN                1043
#define IDC_BROWSE_END                  1044
#define IDC_SEPARATOR                   1045
#define IDC_CUSTOMIZE                   1046
#define IDC_COMBO_ICON                  1047
#define ID_HEADER                       40000
#define ID_PARAGRAPH                    40001
#define ID_BREAK                        40002
#define ID_BOLD                         40003
#define ID_ITALIC                       40004
#define ID_UNDERLINE                    40005
#define ID_FONT                         40006
#define ID_COLOR                        40007
#define ID_PICTURE                      40008
#define ID_HYPERLINK                    40009
#define ID_TABLE                        40010
#define ID_HORZ_LINE                    40011
#define ID_COMMENT                      40012
#define ID_ALIGN_LEFT                   40013
#define ID_CENTER                       40014
#define ID_ALIGN_RIGHT                  40015
#define ID_JUSTIFY                      40016
#define ID_NUMBERING                    40017
#define ID_BULLETS                      40018
#define ID_UNINDENT                     40019
#define ID_INDENT                       40020
#define ID_HIGHLIGHT                    40021
#define ID_FONT_COLOR                   40022
#define ID_FORM                         40023
#define ID_CUSTOMIZE                    40024
#define ID_FORM_FORM                    40025
#define ID_TEXTBOX                      40026
#define ID_PASSWORD                     40027
#define ID_TEXTAREA                     40028
#define ID_CHECKBOX                     40029
#define ID_OPTIONBUTTON                 40030
#define ID_GROUPBOX                     40031
#define ID_DROPDOWNBOX                  40032
#define ID_LISTBOX                      40033
#define ID_PUSHBUTTON                   40034
#define ID_ADVANCEDBUTTON               40035
#define ID_HIDDENINPUT                  40036
#define ID_OBJECT                       40037
#define ID_CAMERA                       40038
#define ID_CD                           40039
#define ID_SCANNER                      40040
#define ID_PRINTER                      40041
#define ID_FUNCTION                     40042
#define ID_CRITICALERROR                40043
#define ID_WARNING                      40044
#define ID_INFORMATION                  40045
#define ID_BLUEFLAG                     40046
#define ID_BACKGROUNDSOUND              40047

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
