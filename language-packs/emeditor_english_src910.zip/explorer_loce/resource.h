//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by explorer_loce.rc
//
#define IDS_SURE_TO_UNINSTALL           1
#define IDS_VERSION                     2
#define IDS_MENU_TEXT                   3
#define IDS_STATUS_MESSAGE              4
#define IDS_INVALID_VERSION             7
#define IDS_SURE_CLEAR_HISTORY          8
#define IDS_POS_LEFT                    11
#define IDS_POS_TOP                     12
#define IDS_POS_RIGHT                   13
#define IDS_POS_BOTTOM                  14
#define IDS_COLLAPSE                    15
#define IDS_STATUS_FORMAT               16
#define IDS_STATUS_LINK_FORMAT          17
#define IDD_PROP                        116
#define IDR_CONTEXT_MENU                117
#define IDD_MAIN                        134
#define IDC_TREE                        1011
#define IDC_COMBO_FOLDER                1017
#define IDC_COMBO_FILTER                1018
#define IDC_STATIC_FILTER               1019
#define IDC_STATIC_ROOT                 1023
#define IDC_ROOT                        1024
#define IDC_COMBO_POS                   1024
#define IDC_STATIC_EXCLUDE              1025
#define IDC_COMBO_EXCLUDE               1026
#define IDC_SINGLE_CLICK_OPEN           1027
#define ID_FILE_RELOAD_ANSI             4110
#define ID_FILE_RELOAD_UNICODE          4257
#define ID_FILE_RELOAD_UTF8             4258
#define ID_FILE_RELOAD_UTF7             4259
#define ID_FILE_RELOAD_UNICODE_BIGENDIAN 4261
#define ID_FILE_RELOAD_DETECT_ALL       4279
#define ID_FILE_RELOAD_BINARY           4438
#define ID_FILE_RELOAD_HEX              4439
#define ID_FILE_RELOAD_DEFINED          6656
#define ID_PROP                         40005
#define ID_REFRESH                      40008
#define ID_CLEAR_HISTORY                40010
#define ID_VIEW_HIDDEN                  40011
#define ID_OPEN_READ_ONLY               40012
#define ID_EXPLORER                     40014
#define ID_DESKTOP                      40015
#define ID_VIEW_DESKTOP_FILES           40016
#define ID_SHOW_EXCLUDE                 40017
#define ID_SHOW_INCLUDE                 40018
#define ID_OPEN                         40022
#define ID_EXPAND                       40023
#define ID_BACK                         40027
#define ID_FORWARD                      40028

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40002
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
