//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by findbar_loce.rc
//
#define IDS_SURE_TO_UNINSTALL           1
#define IDS_VERSION                     2
#define IDS_MENU_TEXT                   3
#define IDS_STATUS_MESSAGE              4
#define IDS_TITLE                       5
#define IDS_INVALID_VERSION             7
#define IDD_PROP                        116
#define IDD_DIALOGBAR                   117
#define IDR_REGEXP_FIND_POPUP           195
#define IDC_FOCUS_VIEW                  1020
#define ID_FIND                         40000
#define ID_BROWSE_REG_EXP               40001
#define ID_PREV                         40002
#define ID_NEXT                         40003
#define ID_INCREMENTAL                  40004
#define ID_OPEN_DOC                     40005
#define ID_CASE                         40006
#define ID_REG_EXP                      40007
#define ID_ESCAPE                       40008
#define ID_ONLY_WORD                    40009
#define ID_AROUND                       40010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
