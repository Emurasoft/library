//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by opendocuments_locj.rc
//
#define IDS_SURE_TO_UNINSTALL           1
#define IDS_VERSION                     2
#define IDS_MENU_TEXT                   3
#define IDS_STATUS_MESSAGE              4
#define IDS_INVALID_VERSION             7
#define IDS_POS_LEFT                    11
#define IDS_POS_TOP                     12
#define IDS_POS_RIGHT                   13
#define IDS_POS_BOTTOM                  14
#define IDD_PROP                        116
#define IDR_CONTEXT_MENU                117
#define IDC_COMBO_POS                   1024
#define ID_GROUP_CLOSE_OTHERS           4388
#define ID_GROUP_CLOSE_LEFT             4389
#define ID_GROUP_CLOSE_RIGHT            4390
#define ID_NEW_GROUP                    4391
#define ID_NEW_GROUP_MINIMIZE           4392
#define ID_MOVE_PREV_GROUP              4396
#define ID_MOVE_NEXT_GROUP              4397
#define ID_SORT_FILE_NAME               4398
#define ID_SORT_TYPE                    4399
#define ID_SORT_MODIFIED                4400
#define ID_SORT_ACCESSED                4401
#define ID_SORT_ASCENDING               4402
#define ID_SORT_DESCENDING              4403
#define ID_AUTO_SORT                    4404
#define ID_PROP                         40005
#define ID_REFRESH                      40008
#define ID_ACTIVATE                     40029
#define ID_CLOSE                        40030
#define ID_SAVE                         40031
#define ID_SELECT_ALL                   40032
#define ID_VIEW_FULL                    40033
#define ID_VIEW_TITLE                   40034
#define ID_VIEW_BLEND                   40035

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
