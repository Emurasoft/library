//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by webpreview_locj.rc
//
#define IDS_SURE_TO_UNINSTALL           1
#define IDS_VERSION                     2
#define IDS_MENU_TEXT                   3
#define IDS_STATUS_MESSAGE              4
#define IDS_INVALID_VERSION             7
#define IDS_POS_LEFT                    11
#define IDS_POS_TOP                     12
#define IDS_POS_RIGHT                   13
#define IDS_POS_BOTTOM                  14
#define IDS_CONFIGS                     15
#define IDD_PROP                        116
#define IDR_CONTEXT_MENU                118
#define IDC_LIST                        1008
#define IDC_AUTO_DISPLAY                1022
#define IDC_COMBO_POS                   1024
#define ID_PROP                         40005
#define ID_REFRESH                      40008
#define ID_BACK                         40009
#define ID_FORWARD                      40010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
