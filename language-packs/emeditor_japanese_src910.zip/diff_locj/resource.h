//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by diff_locj.rc
//
#define IDS_SURE_TO_UNINSTALL           1
#define IDS_VERSION                     2
#define IDS_MENU_TEXT                   3
#define IDS_STATUS_MESSAGE              4
#define IDS_INVALID_VERSION             7
#define IDS_FILE_NOT_OPENED             10
#define IDS_SAME_FILE_SPECIFIED         11
#define IDS_IDENTICAL                   12
#define IDS_TOO_DIFFERENT               13
#define IDS_POS_LEFT                    14
#define IDS_POS_TOP                     15
#define IDS_POS_RIGHT                   16
#define IDS_POS_BOTTOM                  17
#define IDD_PROP                        116
#define IDR_CONTEXT_MENU                117
#define IDD_DIFF                        118
#define IDC_LIST                        1008
#define IDC_DIFF                        1011
#define IDC_FILE_LEFT                   1012
#define IDC_FILE_RIGHT                  1013
#define IDC_SELECT_LEFT                 1014
#define IDC_SELECT_RIGHT                1015
#define IDC_TAB                         1020
#define IDC_SPIN_TAB                    1021
#define IDC_SHOW_ONLY_CHANGES           1022
#define IDC_RUN_STARTUP                 1023
#define IDC_COMBO_POS                   1024
#define IDS_TEXT_NOT_FOUND_ABOVE        1070
#define IDS_SEARCHED_TILL_END           1072
#define IDS_SEARCHED_TILL_TOP           1075
#define IDS_TEXT_NOT_FOUND_BELOW        1088
#define IDS_TEXT_NOT_FOUND_ALL          1089
#define ID_PROP                         40005
#define ID_BOOKMARK_ALL                 40007
#define ID_REFRESH                      40008
#define ID_JUMP_LEFT                    40009
#define ID_JUMP_RIGHT                   40010
#define ID_NEXT_CHANGE                  40011
#define ID_PREV_CHANGE                  40012
#define ID_FONT                         40013
#define ID_COLOR_LEFT                   40014
#define ID_COLOR_RIGHT                  40015
#define ID_FIND_PREV                    40016
#define ID_FIND_NEXT                    40017
#define ID_COLOR_FIND                   40018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
