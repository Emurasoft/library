//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by wordcount_locj.rc
//
#define IDS_SURE_TO_UNINSTALL           1
#define IDS_VERSION                     2
#define IDS_MENU_TEXT                   3
#define IDS_STATUS_MESSAGE              4
#define IDS_CHARACTERS                  5
#define IDS_SELECTION                   6
#define IDS_INVALID_VERSION             7
#define IDS_DOCUMENT                    8
#define IDS_QUERY                       9
#define IDS_WIDTHS                      10
#define IDS_POS_LEFT                    11
#define IDS_POS_TOP                     12
#define IDS_POS_RIGHT                   13
#define IDS_POS_BOTTOM                  14
#define IDS_SURE_RESET                  15
#define IDS_WORDS                       16
#define IDS_LINES                       17
#define IDD_CUST_PROP                   116
#define IDR_ARG_POPUP                   117
#define IDD_MAIN                        118
#define IDR_CONTEXT_MENU                118
#define IDD_CUSTOMIZE                   146
#define IDD_PROP                        147
#define IDC_PROGRESS                    1000
#define IDC_AUTO_REFRESH                1001
#define IDC_REFRESH                     1002
#define IDC_CUSTOMIZE                   1003
#define IDC_RESET                       1004
#define IDC_CHECK_REGEXP                1006
#define IDC_EDIT_REGEXP                 1007
#define IDC_LIST                        1008
#define IDC_BROWSE_REGEXP               1008
#define IDC_RADIO_CHARS                 1009
#define IDC_RADIO_WIDTHS                1010
#define IDC_RADIO_WORDS                 1011
#define IDC_RADIO_LINES                 1012
#define IDC_COMBO_POS                   1024
#define IDC_NEW                         1025
#define IDC_DELETE                      1026
#define IDC_COPY                        1027
#define IDC_UP                          1028
#define IDC_DOWN                        1029
#define IDC_PROP                        1030
#define IDC_TITLE                       1034
#define ID_REFRESH                      40008
#define ID_CUSTOMIZE                    40010
#define ID_PROP                         40012

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
