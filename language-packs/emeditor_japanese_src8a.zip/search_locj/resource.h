//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by search_locj.rc
//
#define IDS_SURE_TO_UNINSTALL           1
#define IDS_VERSION                     2
#define IDS_MENU_TEXT                   3
#define IDS_STATUS_MESSAGE              4
#define IDS_INVALID_VERSION             7
#define IDS_FILE                        8
#define IDS_LINE                        9
#define IDS_POS_LEFT                    11
#define IDS_POS_TOP                     12
#define IDS_POS_RIGHT                   13
#define IDS_POS_BOTTOM                  14
#define IDD_PROP                        116
#define IDD_SEARCH                      118
#define IDC_FIND                        1005
#define IDC_SEARCH                      1006
#define IDC_LIST                        1008
#define IDC_CASE                        1009
#define IDC_REGEX                       1010
#define IDC_COMBO_POS                   1024

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
