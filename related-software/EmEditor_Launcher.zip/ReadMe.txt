
  EmEditor Launcher Instructions
  --------------------------------------------------------------------
  To manually replace the original notepad.exe with the included file
  copy the included notepad.exe to the following directories in the
  order shown below:

  %windir%\system32\dllcache
  %windir%\system32
  %windir%\

  Windows will try to restore the original notepad.exe automatically
  and you might see a warning where you are asked to insert the
  Windows CD, then click cancel. If you copy the files in the wrong
  order or do it to slow Windows might restore the files before you
  managed to copy notepad.exe into all of the three directories.
  If your Windows installation files is available when replacing
  notepad.exe the original notepad.exe might be restored. This could
  happen if the Windows installation CD is inserted or you copied
  the Windows CD to your harddisk while you try to replace notepad.exe.
  If you want to you could also create a copy of the original
  notepad.exe before you replace with the included file manually.
  
  If you don't want to replace your original notepad.exe you could 
  rename this file using any name you want and place this file
  somewhere in your path like "%windir%\EmEditor.exe".

  Using Install.cmd the orignal notepad.exe will be copied to 
  notepad.org in all the directories listed above and then the new
  notepad.exe will be copied into those directories.

  Uninstall.cmd will copy notepad.org to notepad.exe for all of the
  directories listed above and then delete notepad.org.


  EmEditor Launcher 1.01 Release notes
  --------------------------------------------------------------------
  Version 1.0:
   - First release

  Version 1.01:
   - Fix: Didn't handle filenames and directories
          with spaces in some cases
   - New: Support for wildcards like * and ? from
          command line. Ex: "notepad c:\windows\*.ini"
          will open all ini files in the windows
          folder. "Notepad.exe *.ini *.txt" will open
          all ini and txt files in the current folder.
  
  Version 1.02:
   - Fix: Now exclude directories when using wildcards
          regardless of what attributes is set.
