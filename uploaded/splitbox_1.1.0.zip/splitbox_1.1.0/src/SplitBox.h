﻿#pragma once

#include <windows.h>

namespace SplitBox
{
	//	プラグインの情報取得
	extern	::LRESULT	GetPluginInfo( ::HWND em, ::UINT_PTR flag );

	//	プロパティあるか？
	extern	bool	HasProperty();

	//	プロパティ開く
	extern	bool	ShowProperty( ::HWND em );

	//	コマンド実行可能か？
	extern	bool	CanCommand( ::HWND em );

	//	チェックが付いた状態か？
	extern	bool	IsChecked( ::HWND em );

	//	コマンド実行
	extern	void	OnCommand( ::HWND em );

	//	イベント応答
	extern	void	OnEvents( ::HWND em, ::UINT nEvent, ::LPARAM lParam );
};

