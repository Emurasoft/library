/* Name it "Hello.java" 
 * Compile it by running "javac Hello.java"
 * Run it by typing "java Hello"
 */

class Hello {
	public static void main(String args[])
	{
    	System.out.println("Hello, world!");
	}
}


