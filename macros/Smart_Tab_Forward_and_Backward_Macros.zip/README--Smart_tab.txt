Written on 2015-12-14 16:16

Having recently migrated from PSPad (for various reasons) my only and dearly
missed functionality are "smart tabs" or "smart spaces", i.e.:

“TAB press will cause the cursor to follow words from previous line(s).”
  (as in PSPad's description)

***Example***
↑ indicates the cursor location
> indicates a line in a text file

> line1 does xyz1;    // comment 1
> line2 does xyz2;    // comment 2
> line three // comment 3
           ↑

executing "smart_tab_forward.jsee"

> line1 does xyz1;    // comment 1
> line2 does xyz2;    // comment 2
> line three          // comment 3

executing "smart_tab_backward.jsee"

> line1 does xyz1;    // comment 1
> line2 does xyz2;    // comment 2
> line t// comment 3



Basically the tab is adapted according to the first previous line which delivers
a suitable tab anchor point (default is to consider the preceeding 20 lines).
It also works with multi-line selections.

Perhaps this is of use for someone.

Best wishes,

Patrick

PS Required files:

● smart_tab_forward.jsee
● smart_tab_backward.jsee
● calc_smart_tab_forward.jsee    // contains a subfunction for smart_tab_forward.jsee
● calc_smart_tab_backward.jsee   // contains a subfunction for smart_tab_forward.jsee

