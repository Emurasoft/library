
Code2HTML   Version 0.6.2

Author: lifesinger
URL: http://lifesinger.3322.org/myblog/?p=169
Last Update: 2006-1-3

Description

This script can convert your code files to color-highlighted HTML files. It supports all the file types that supported by EmEditor. The color scheme is based on EmEditor, and the syntax files are exported directly from EmEditor. If you want the script to support more file types, you can open the file "More EmEditor - Syntax Files.lnk" in syntaxfiles folder to download more syntax files.


Usage

Just click the script and select your code file or drag a code file to this script file.


More

If you don't want to show line numbers, please open code2html.vbs with your favorite text editor, and edit this line below:
	Dim ShowLinenum : ShowLineNum = True
to
	Dim ShowLinenum : ShowLineNum = False

If you want to change the color scheme, you can find this part in the script file:

	Sub getcolor() 'define foregound and background color
		foreground.Add "0", "#000000"   : background.Add "0", "#FFFFFF"
		foreground.Add "1",  "#000000"  : background.Add "1",  "#FFFF00"
		foreground.Add "2",  "#800080"  : background.Add "2",  "#FFFFFF"
		foreground.Add "3",  "#FF0000"  : background.Add "3",  "#FFFFFF"
		foreground.Add "4",  "#0000FF"  : background.Add "4",  "#FFFFFF"
		foreground.Add "5",  "#AA5500" : background.Add "5",  "#FFFFFF"
		foreground.Add "6",  "#800040" : background.Add "6",  "#FFFFFF"
		foreground.Add "7",  "#008080" : background.Add "7",  "#FFFFFF"
		foreground.Add "8",  "#000000" : background.Add "8",  "#FF0000"
		foreground.Add "9",  "#000000" : background.Add "9",  "#00FFFF"
		foreground.Add "10", "#000000" : background.Add "10",  "#40FF40"
		bgcolor              = "#FFFFFF"
		textcolor            = "#000000"
		commentcolor     = "#008000"
		codecolor           = "#800000"
		linenum_color     = "#666666"
		linenum_bgcolor  = "#E8E8E8"
		quotecolor          = "#FF00FF"
	End Sub

then change the color values to whatever you like.


Any Comments are Welcome! And Happy New Year to All!


lifesinger  2006.1

----
Modified by Yutaka Emura to make it work as EmEditor macro: October 30, 2006
