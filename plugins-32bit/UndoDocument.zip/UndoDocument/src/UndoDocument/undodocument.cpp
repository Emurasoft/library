#include "stdafx.hpp"

#include "resource.h"

#define ETL_FRAME_CLASS_NAME CMyFrame
#include "etlframe.h"

#include "undodocument.hpp"

_ETL_IMPLEMENT
