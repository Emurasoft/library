#pragma once

#define NOMINMAX
#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <windowsx.h>
#include <tchar.h>

#include <limits>
#include <string>
#include <algorithm>
#include <list>
#include <functional>

#include <boost/bind.hpp>
