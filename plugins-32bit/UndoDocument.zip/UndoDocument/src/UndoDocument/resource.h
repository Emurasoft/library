//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by undodocument.rc
//
#define IDS_MENU_TEXT                   101
#define IDS_STATUS_MESSAGE              102
#define IDB_BITMAP                      102
#define IDS_VERSION                     103
#define IDB_16C_24                      103
#define IDB_TRUE_16_BW                  104
#define IDS_SURE_TO_UNINSTALL           104
#define IDB_TRUE_16_DEFAULT             105
#define IDB_TRUE_16_HOT                 106
#define IDB_TRUE_24_BW                  107
#define IDB_TRUE_24_DEFAULT             108
#define IDB_TRUE_24_HOT                 109

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        110
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
