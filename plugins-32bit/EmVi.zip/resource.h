//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by EmVi.rc
//
#define IDS_SURE_TO_UNINSTALL           1
#define IDS_VERSION                     2
#define IDS_MENU_TEXT                   3
#define IDS_STATUS_MESSAGE              4
#define IDS_WORDS_CONTAINED             5
#define IDS_TITLE                       5
#define IDS_INVALID_VERSION             7
#define IDS_FILE                        8
#define IDS_LINE                        9
#define IDS_POS_LEFT                    11
#define IDS_POS_TOP                     12
#define IDS_POS_RIGHT                   13
#define IDS_POS_BOTTOM                  14
#define IDB_BITMAP                      101
#define IDB_256C_16_BW                  103
#define IDD_FIND_BAR                    103
#define IDB_256C_16_DEFAULT             104
#define IDB_256C_16_HOT                 105
#define IDB_256C_24_BW                  106
#define IDB_256C_24_DEFAULT             107
#define IDB_256C_24_HOT                 108
#define IDB_TRUE_16_BW                  109
#define IDB_TRUE_16_DEFAULT             110
#define IDB_TRUE_16_HOT                 111
#define IDB_TRUE_24_BW                  112
#define IDB_TRUE_24_DEFAULT             113
#define IDB_TRUE_24_HOT                 114
#define IDB_16C_24                      115
#define IDD_PROP                        116
#define IDD_DIALOGBAR                   117
#define IDB_TOOLBAR                     142
#define IDR_REGEXP_FIND_POPUP           195
#define ID_COMMANDLINE					30000
#define ID_FIND_OK						30001
#define ID_COMMANDLINE_OK				30002
#define ID_FIND                         40000
#define ID_BROWSE_REG_EXP               40001
#define ID_PREV                         40002
#define ID_NEXT                         40003
#define ID_INCREMENTAL                  40004
#define ID_OPEN_DOC                     40005
#define ID_CASE                         40006
#define ID_REG_EXP                      40007
#define ID_ESCAPE                       40008
#define ID_ONLY_WORD                    40009
#define ID_AROUND                       40010
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        143
#define _APS_NEXT_COMMAND_VALUE         40006
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
