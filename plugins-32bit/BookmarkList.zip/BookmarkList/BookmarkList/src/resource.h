//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDS_MENU_TEXT                   1
#define IDS_STATUS_MESSAGE              2
#define IDS_SURE_TO_UNINSTALL           3
#define IDS_VERSION_TEXT                4
#define IDS_VERSION                     5
#define IDB_BITMAP                      101
#define IDD_FORMVIEW                    101
#define IDB_16C_24                      102
#define IDB_256C_16_DEFAULT             103
#define IDB_256C_24_DEFAULT             104
#define IDB_256C_16_BW                  105
#define IDB_256C_24_BW                  106
#define IDB_256C_16_HOT                 107
#define IDB_256C_24_HOT                 108
#define IDB_TRUE_16_DEFAULT             109
#define IDB_TRUE_24_DEFAULT             110
#define IDB_TRUE_16_BW                  111
#define IDB_TRUE_24_BW                  112
#define IDB_TRUE_16_HOT                 113
#define IDB_TRUE_24_HOT                 114
#define IDC_LIST1                       1000
#define IDC_CHECK1                      1001
#define IDC_BUTTON1                     1002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        115
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
