#define MAX_LINE_LENGTH	2048

extern TCHAR g_szFileName[];
extern int g_nLineNumber;
extern _GET_LINE_INFO g_LineInfo;
extern TCHAR g_szSentence[];
extern SIZE g_PageSize;
extern POINT g_ptCaret;
